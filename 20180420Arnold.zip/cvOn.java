package smartthermo;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.InetAddress;
import java.net.Socket;


public class cvOn {
   
	private static Socket socket;

   public static void main(String args[])
   {
       try
       {
           String host = "localhost";
           int port = 7777; //Arnold: port given by jar start = 7777
           InetAddress address = InetAddress.getByName(host);
           socket = new Socket(address, port);

           //Send the message to the server
           OutputStream os = socket.getOutputStream();
           OutputStreamWriter osw = new OutputStreamWriter(os);
           BufferedWriter bw = new BufferedWriter(osw);

           //$CV-CONNECT-$-123123
           String cvConnect = "$CV-CONNECT-$-123123"; 
           //Arnold: $CV-CONNECT-$-123123 command, 123123 = connection-code
           String sendMessage = cvConnect + "\n";
           bw.write(sendMessage);
           bw.flush();
           System.out.println("\t Connect to CV: " + sendMessage);    
           
           getReturnMessageCV(); //Get the return message from CV server
           
           //Turn cvOn.
           String cvOn = "$CV-ACT-$50$40"; //Arnold: turn CV on with pump 50, heater 40.
           String sendMessagecvOn = cvOn + "\n";
           bw.write(sendMessagecvOn);
           bw.flush();
           System.out.println("\t Turn CV On: " + sendMessagecvOn);
           
           getReturnMessageCV(); //Get the return message from CV server
                     
           getCVStatus(bw);
           getReturnMessageCV(); //Get the return message from CV server
           
                      
       }
   
       catch (Exception exception)
       {
          // exception.printStackTrace();
       }
       finally
       {
    	   System.out.println("cv On");
    	       	   
           //Closing the socket
           try
           {
               socket.close();
           }
           catch(Exception e)
           {
               e.printStackTrace();
           }
       }
   }

private static void getCVStatus(BufferedWriter bw) throws IOException {
	//Ask for current status CV.
	   String cvStatus = "$CV-STAT?"; 
	   String sendMessageStatus = cvStatus + "\n";
	   bw.write(sendMessageStatus);
	   bw.flush();
	   System.out.println("\t Ask for current CV status: " + sendMessageStatus);
}

private static void getReturnMessageCV() throws IOException {
	//Get the return message from CV server
	   InputStream is = socket.getInputStream();
	   InputStreamReader isr = new InputStreamReader(is);
	   BufferedReader br = new BufferedReader(isr);
	   String message = br.readLine();  // Arnold output of cv jar.
	   System.out.println("\t Message received from the server : " +message);
}
}




