package smartthermo;


public class ControlTempRoom {

	public static void main(String[] args) {
		//readTempRoom getTempRoom = new readTempRoom();
		//int roomTemp = getTempRoom;
		double readTempRoom = 21;
		double setTempRoom = 23;
		
		double readPumpPressure = 1.50;
		double maxPumpPressure = 2.00;
		double minPumpPressure = 1.45;
		
		String cvOn = "$CV-ACT-$50$40"; //Arnold: turn CV on with pump 50, heater 40.
		String cvOff = "$CV-ACT-$0$0"; //Arnold: turn CV off with pump 0, heater 0.
		
		
		try {
		
		CONTROLTEMPROOMLOOP:	
		while (true) {
			while (setTempRoom > readTempRoom && readPumpPressure < maxPumpPressure && readPumpPressure > minPumpPressure ){
				//Turn cvOn
				readTempRoom+=0.20;
				readPumpPressure+=0.05;
				System.out.println("Status CHS cvOn:" +" "+ cvOn +" "+ readTempRoom +" "+ readPumpPressure);
				Thread.sleep((1000*60*1)/24); //1/24 minute
				} 
				//Turn cvOff
				readTempRoom -=0.05;
				readPumpPressure -=0.01;
				System.out.println("Status CHS cvOff:" +" "+ cvOff +" "+ readTempRoom +" "+ readPumpPressure);
				Thread.sleep((1000*60*1)/24); //1/24 minute
			  
			continue CONTROLTEMPROOMLOOP;
	        }
		} catch (InterruptedException e) {
	        e.printStackTrace();
	    }
				
	}
}
